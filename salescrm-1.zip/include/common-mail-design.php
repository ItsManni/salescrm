<?php

$mail_header = "<div style='background-color:#fbfbfc;margin:0'>
<font color='#888888'>
</font><font color='#888888'>
</font><font color='#888888'>
</font><table style='font-family:'open sans','arial','verdana',sans-serif;font-size:14px;color:#444e61;width:98%;max-width:600px;float:none;margin:0 auto' border='0' cellpadding='0' cellspacing='0' valign='top' align='center'>
  <tbody>
	<tr>
	  <td height='24' style='line-height:1px;font-size:1px'>&nbsp;</td>
	</tr>
	<tr align='middle'>
	  <td><img src='https://ci5.googleusercontent.com/proxy/XSnqOpbegKTn2oJAmMl_Udd5vLuJdpE1ZcvcTxOLDVYTcSYvtn5R8_pNwccgC1LZIgjbxcoxN9L0p39d6MEgocmf-0kRcoTjH2PtsCvtjlqQQYNb2w=s0-d-e1-ft#https://www.webomates.com/wp-content/uploads/2021/03/webomates.png' height='37' class='CToWUd' data-bit='iit'></td>
	</tr>
	<tr>
	  <td height='24' style='line-height:1px;font-size:1px'>&nbsp;</td>
	</tr>";

	$mail_footer = "<tr>
					  <td><span style='font-family:'open sans','arial','verdana',sans-serif;font-size:16px;color:#444e61'>Thanks and Regards,</span></td>
					</tr>
					<tr>
					  <td><span style='font-family:'open sans','arial','verdana',sans-serif;font-size:18px;color:#20252e;font-weight:bold'>Team Webomates</span></td>
					</tr>
					
					
					<tr>
					  <td height='32' style='line-height:1px;font-size:1px'>&nbsp;</td>
					</tr>
				  </tbody>
				</table></td>
			</tr>
		  </tbody>
		</table></td>
	</tr>
	<tr>
	  <td height='24' style='line-height:1px;font-size:1px'>&nbsp;</td>
	</tr>
	<tr>
	  <td style='font-family:'open sans','arial',sans-serif;font-size:12px;line-height:130%;color:#9f9f9f;text-align:center' align='center'>© 2023 Webomates.&nbsp;All rights reserved. <br>1177 High Ridge Road,
	  #212, Stamford, CT 06905<br><a href='https://www.webomates.com/' title='webomates' style='color:#9f9f9f;font-family:'open sans','arial','verdana',sans-serif' target='_blank' >webomates.com</a></td>
	</tr>
	<tr>
	  <td style='font-size:12px;color:#d0d3d6;text-align:center'>___</td>
	</tr>
	<tr>
	  <td style='font-size:12px;padding:15px;color:#9f9f9f;text-align:center'>If you did not make this request, please contact us by replying to this email.</td></tr></tbody></table><font color='#888888'>
</font></div>";
?>