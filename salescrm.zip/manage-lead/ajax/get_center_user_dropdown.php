<?php 
@session_start();
require_once('../../include/autoloader.inc.php');
$dbh = new Dbh();
$conn = $dbh->_connectodb();
$CenterID = $_POST['CenterID'];
$Users = new Users($conn);
$center_user_array = $Users->getAllCounsellorByCenterID($CenterID);
?>
<option value="">Please Select Counsellor</option>
<?php
foreach ($center_user_array as $Center_User) 
{
?>
    <option value="<?php echo $Center_User['ID']; ?>"><?php echo $Center_User['Name']; ?></option>
<?php
}
?>