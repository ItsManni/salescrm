<?php @session_start(); ?>
<?php
require_once('../include/autoloader.inc.php');
$conf = new Conf();
$_ProductIcon = $conf->_ProductIcon;
?>
<meta charset="UTF-8">
<meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
<meta http-equiv="X-UA-Compatible" content="IE=edge">


<!-- FAVICON -->
<link rel="apple-touch-icon" sizes="180x180" href="<?= $_ProductIcon ?>">
<link rel="icon" type="image/png" sizes="32x32" href="<?= $_ProductIcon ?>">
<link rel="icon" type="image/png" sizes="16x16" href="<?= $_ProductIcon ?>">
<link rel="manifest" href="../project-assets/images/favicon/site.webmanifest">
<link rel="mask-icon" href="../project-assets/images/favicon/safari-pinned-tab.svg" color="#5bbad5">
<meta name="msapplication-TileColor" content="#da532c">
<meta name="theme-color" content="#ffffff">


<!-- DATA TABLE SCSS -->
<link href="../theme-assets/scss/plugins/_dataTables.bootstrap.scss" rel="stylesheet">
<link href="../theme-assets/scss/plugins/_buttons.bootstrap5.scss" rel="stylesheet">
<link href="../theme-assets/scss/plugins/_responsive.bootstrap.scss" rel="stylesheet">


<!-- BOOTSTRAP CSS -->
<link id="style" href="../theme-assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- STYLE CSS -->
 <link href="../theme-assets/css/style.css" rel="stylesheet">

<!-- Plugins CSS -->
<link href="../theme-assets/css/plugins.css" rel="stylesheet">

<!--- FONT-ICONS CSS -->
<link href="../theme-assets/css/icons.css" rel="stylesheet">

<!-- INTERNAL Switcher css -->
<link href="../theme-assets/switcher/css/switcher.css" rel="stylesheet">
<link href="../theme-assets/switcher/demo.css" rel="stylesheet">

<!-- PROJECT CSS -->
<link href="../project-assets/css/style.css" rel="stylesheet">

<!-- Alertify -->

<link rel="stylesheet" media="screen, print" href="../theme-assets/plugins/alertifyjs/css/alertify.css">
<link rel="stylesheet" media="screen, print" href="../theme-assets/plugins/alertifyjs/css/themes/default.min.css">



