<div class="modal fade" id="quick_lead_details_modal" tabindex="1">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content modal-content-demo">
            <div class="modal-header">
                <h3 class="modal-title" id="LeadDetailsHeading">Lead Details</h3>
                <button class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                    <div id="leadModalContainer"></div>

            </div>
        </div>
    </div>
</div>